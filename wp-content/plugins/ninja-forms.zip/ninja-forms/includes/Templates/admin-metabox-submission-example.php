<h4><?php esc_html_e( 'Submission Data', 'ninja-forms' ); ?></h4>

<?php
echo "<pre>";
var_dump($data);
echo "</pre>";
?>