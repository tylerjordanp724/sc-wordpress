<?php

interface NF_Conversion
{
    public function run();
}